window.MIMOSA_TEST_REQUIRE_CONFIG = {
  "paths": {
    "jquery": "vendor/jquery/jquery",
    "d3": "vendor/d3/d3"
  },
  "baseUrl": "/js"
};
window.MIMOSA_TEST_MOCHA_SETUP = {
  "ui": "bdd",
  "globals": [
    "$"
  ]
};
window.MIMOSA_TEST_SPECS = [];